﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_ventas.ModelsClass
{
   public class TextBoxEvent
    {
        public void textKeyPress(KeyPressEventArgs e) //Programar funcionamiento de campos  de texto tipo string
        {
            //Condicion que solo permite ingresar datos de tipo texto
            if (char.IsLetter(e.KeyChar)) { e.Handled = false; }
            //Condicion que nos permite utilizar la tecla backspace (eliminar)
            else if (char.IsControl(e.KeyChar)) { e.Handled = false; }
            //Condicion que nos permite utilizar la tecla espacio
            else if (char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }
        public void numberKeyPress(KeyPressEventArgs e) //numeros enteros
        {
            //Condicion que nos permite ingresar solo datos numericos
            if (char.IsDigit(e.KeyChar)) { e.Handled = false; }
            if(char.IsLetter(e.KeyChar)) { e.Handled = true; } //bloquea letras
        }
        public void numberDecimalKeyPress(TextBox textBox,KeyPressEventArgs e) //numeros decimales
        {
            //Condicion que nos permite ingresar solo datos numericos
            if (char.IsDigit(e.KeyChar)) { e.Handled = false; }
            // Condicion que nos permite utilizar la tecla backspace(eliminar)
            else if (char.IsControl(e.KeyChar)) { e.Handled = false; }
            //Condicion que verifica punto decimal
            else if((e.KeyChar=='.')&&(!textBox.Text.Contains("."))) { e.Handled = false; }
            else { e.Handled = true; }
        }

        internal void numberDecimalKeyPress(KeyPressEventArgs e)
        {
            throw new NotImplementedException();
        }
    }

}
