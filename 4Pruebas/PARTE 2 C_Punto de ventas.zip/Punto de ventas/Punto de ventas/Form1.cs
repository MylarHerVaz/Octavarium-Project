﻿using Punto_de_ventas.Connection;
using Punto_de_ventas.Models;
using Punto_de_ventas.ModelsClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto_de_ventas
{
    public partial class Form1 : Form
    {
        TextBoxEvent evento = new TextBoxEvent();
        Cliente cliente = new Cliente();
        List<Clientes> numCliente = new List<Clientes>();
        private string accion = "insert", deudaActual, pago, dia, fecha;
        private int paginas = 4, pageSize = 10, maxReg, pageCount, numPagi = 1, idCliente = 0;


        public Form1()
        {
            InitializeComponent();
         
            /**********************************************
                        Código del cliente
          * *********************************************/
            #region  
            radioButton_IngresarCliente.Checked = true; //Cuando se inicie el sistema este radio estará seleccionado
            radioButton_IngresarCliente.ForeColor = Color.DarkCyan;
            #endregion
        }
        /**********************************************
                   Código del Paginador
     * *********************************************/
        #region

        private void cargarDatos()
        {
            switch (paginas)
            {
                case 1:
                    numCliente = cliente.getClientes();
                    cliente.searchCliente(dataGridView_Cliente, "", 1, pageSize);

                    maxReg = numCliente.Count();
                    break;
            }

            pageCount = (maxReg / pageSize);

            //Ajuste el numer de la pagina si la ultima pagina contiene una parte de la pagina.
            if ((maxReg % pageSize) > 0)
            {
                pageCount += 1;
            }
            label_PaginasCliente.Text = "Paginas" + "1" + "/" + pageCount.ToString();

        }




        #endregion

        /**********************************************
                       Código del cliente
         * *********************************************/

        #region  
        private void button_Clientes_Click(object sender, EventArgs e) 
        {
            paginas = 1;
            accion = "insert";
            //se manda llamar a la pag1 del tabcontrol
            tabControl1.SelectedIndex = 1;
            cargarDatos();
            button_Clientes.Enabled = false;
            button_Ventas.Enabled = true;
            button_Productos.Enabled = true;
            button_Compras.Enabled = true;
            button_Dpto.Enabled = true;
            button_Compras.Enabled = true;
           
                
        }
        private void radioButton_IngresarCliente_CheckedChanged(object sender, EventArgs e)
        {
            radioButton_IngresarCliente.ForeColor = Color.DarkCyan;
            radioButton_PagosDeudas.ForeColor = Color.Black;
            textBox_Nombre.ReadOnly = false; //Habilitar campo de texto
            textBox_Apellido.ReadOnly = false;
            textBox_Direccion.ReadOnly = false;
            textBox_Telefono.ReadOnly = false;
            textBox_PagoscCliente.ReadOnly = true;//Deshabilitar campo de texto
            label_PagoCliente.Text = "Pagos de deudas";
            label_PagoCliente.ForeColor = Color.DarkCyan;


        }

        private void radioButton_PagosDeudas_CheckedChanged(object sender, EventArgs e)
        {
            radioButton_PagosDeudas.ForeColor = Color.DarkCyan;
            radioButton_IngresarCliente.ForeColor = Color.Black;
            textBox_Nombre.ReadOnly = true;
            textBox_Apellido.ReadOnly = true;
            textBox_Direccion.ReadOnly = true;
            textBox_Telefono.ReadOnly = true;
            textBox_PagoscCliente.ReadOnly = false;
        }

        private void textBox_Nombre_TextChanged(object sender, EventArgs e)
        {
            if (textBox_Nombre.Text =="")
            {
                label_Nombre.ForeColor = Color.Red;
            }
            else
            {
                label_Nombre.Text = "Nombre completo";
                label_Nombre.ForeColor = Color.Green;
            }
        }

        private void textBox_Nombre_KeyPress(object sender, KeyPressEventArgs e) //Evalua si esta vacio el campo
        {
            evento.textKeyPress(e);
        }
        private void textBox_Id_KeyPress(object sender, KeyPressEventArgs e)
        {
            evento.numberKeyPress(e);
        }
        private void textBox_Id_TextChanged(object sender, EventArgs e)
        {
            if (textBox_Id.Text == "")
            {
                label_Id.ForeColor = Color.Red;
            }
            else
            {
                label_Id.Text = "ID";
                label_Id.ForeColor = Color.Green;
            }
        }
        private void textBox_Apellido_TextChanged(object sender, EventArgs e)
        {
            if (textBox_Apellido.Text == "")
            {
                label_Apellido.ForeColor = Color.Red;
            }
            else
            {
                label_Apellido.Text = "Apellido";
                label_Apellido.ForeColor = Color.Green;
            }
        }
        private void textBox_Apellido_KeyPress(object sender, KeyPressEventArgs e)
        {
            evento.textKeyPress(e);
        }
        private void textBox_Direccion_TextChanged(object sender, EventArgs e)
        {
            if (textBox_Direccion.Text == "")
            {
                label_Direccion.ForeColor = Color.Red;
            }
            else
            {
                label_Direccion.Text = "Direccion";
                label_Direccion.ForeColor = Color.Green;
            }

        }

       

        private void textBox_Direccion_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

      

        private void textBox_Telefono_TextChanged(object sender, EventArgs e)
        {
            if (textBox_Telefono.Text == "")
            {
                label_Telefono.ForeColor = Color.Red;
            }
            else
            {
                label_Telefono.Text = "Telefono";
                label_Telefono.ForeColor = Color.Green;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox_Telefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            evento.numberKeyPress(e);
        }

        

        private void textBox_PagoscCliente_TextChanged(object sender, EventArgs e)
        {
            if (textBox_PagoscCliente.Text == "")
            {
                label_PagoCliente.ForeColor = Color.Red;
            }
            else
            {
                label_PagoCliente.Text = "Pagos de deudas";
                label_PagoCliente.ForeColor = Color.Green;
            }
        }

        private void textBox_PagoscCliente_KeyPress(object sender, KeyPressEventArgs e)
        {
            evento.numberDecimalKeyPress(textBox_PagoscCliente,e);
        }

        private void button_GuardarCliente_Click(object sender, EventArgs e)
        {
            if (radioButton_IngresarCliente.Checked)
            {
                guardarCliente();
            }
        }
        private void guardarCliente()
        {
            if (textBox_Id.Text=="")
            {
                label_Id.Text = "Ingrese el ID";
                label_Id.ForeColor = Color.Orange;
                textBox_Id.Focus();
            }
            else
            {
                if (textBox_Nombre.Text=="")
                {
                    label_Nombre.Text = "Ingrese el nombre completo";
                    label_Nombre.ForeColor = Color.Orange;
                    textBox_Nombre.Focus();
                }
                else
                {
                    
            
                        if (textBox_Apellido.Text == "")
                        {
                            label_Apellido.Text = "Ingrese el Apellido";
                            label_Apellido.ForeColor = Color.Orange;
                            textBox_Apellido.Focus();
                        }
                        else
                        {
                        if (textBox_Direccion.Text == "")
                        {
                            label_Direccion.Text = "Ingrese la direccion";
                            label_Direccion.ForeColor = Color.Orange;
                            textBox_Direccion.Focus();
                        }
                        else
                        {
                            if (textBox_Telefono.Text == "")
                            {
                                label_Telefono.Text = "Ingrese el Telefono";
                                label_Telefono.ForeColor = Color.Orange;
                                textBox_Telefono.Focus();
                            }
                            else
                            {
                                string ID = textBox_Id.Text;
                                string Nombre = textBox_Nombre.Text;
                                string Apellido = textBox_Apellido.Text;
                                string Direccion = textBox_Direccion.Text;
                                string Telefono = textBox_Telefono.Text;
                                if (accion == "insert")
                                {
                                    cliente.insertCliente(ID, Nombre,Apellido,Direccion,Telefono);
                                }
                                restablecerCliente();
                            }
                        }
                    }
                    }

            }
            
        }

        private void button_PrimerosClientes_Click(object sender, EventArgs e)
        {
            numPagi = 1;
            label_PaginasCliente.Text = "paginas" + numPagi.ToString() + "/" + pageCount.ToString();
            cliente.searchCliente(dataGridView_Cliente, "", 1,pageSize);
        }

        private void button_AnteriosClientes_Click(object sender, EventArgs e)
        {
            if (numPagi > 1)
            {
                numPagi -= 1;
                label_PaginasCliente.Text = "paginas" + numPagi.ToString() + "/" + pageCount.ToString();
                cliente.searchCliente(dataGridView_Cliente, "", numPagi, pageSize);
            }

        }

        private void button_SiguientesClientes_Click(object sender, EventArgs e)
        {
            if (numPagi < pageCount)
            {
                numPagi += 1;
                label_PaginasCliente.Text = "paginas" + numPagi.ToString() + "/" + pageCount.ToString();
                cliente.searchCliente(dataGridView_Cliente, "", numPagi, pageSize);
            }
        }

        private void button_UltimosClientes_Click(object sender, EventArgs e)
        {
            numPagi = pageCount;
            label_PaginasCliente.Text = "paginas" + numPagi.ToString() + "/" + pageCount.ToString();
            cliente.searchCliente(dataGridView_Cliente, "", pageCount, pageSize);
        }

        private void restablecerCliente()
        {
            cargarDatos();
            textBox_Id.Text = "";
            textBox_Nombre.Text = "";
            textBox_Apellido.Text = "";
            textBox_Direccion.Text = "";
            textBox_Telefono.Text = "";
            textBox_PagoscCliente.Text = "";
            textBox_Id.Focus();
            textBox_BuscarCliente.Text = "";
            label_Id.ForeColor = Color.LightSlateGray;
            label_Nombre.ForeColor = Color.LightSlateGray;
            label_Apellido.ForeColor = Color.LightSlateGray;
            label_Direccion.ForeColor = Color.LightSlateGray;
            label_Telefono.ForeColor = Color.LightSlateGray;
            label_PagoCliente.ForeColor = Color.LightSlateGray;
            label_PagoCliente.Text = "Pagos de deudas ";
            radioButton_IngresarCliente.Checked = true;
            radioButton_IngresarCliente.ForeColor = Color.DarkCyan;
            accion = "insert";
            idCliente = 0;

        }
        private void button_Cancelar_Click(object sender, EventArgs e)
        {
            restablecerCliente()
        }

        private void dataGridView_Cliente_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView_Cliente.Rows.Count != 0)
            {
                dataGridViewCliente();
            }
        }

        private void dataGridView_Cliente_KeyUp(object sender, KeyEventArgs e)
        {
            if (dataGridView_Cliente.Rows.Count != 0)
            {
                dataGridViewCliente();
            }
        }

        private void dataGridViewCliente()
        {
            accion = "update";
            idCliente = Convert.ToInt16(dataGridView_Cliente.CurrentRow.Cells[0].Value);
            textBox_Id.Text = Convert.ToString(dataGridView_Cliente.CurrentRow.Cells[1].Value);
            textBox_Nombre.Text = Convert.ToString(dataGridView_Cliente.CurrentRow.Cells[2].Value);
            textBox_Apellido.Text = Convert.ToString(dataGridView_Cliente.CurrentRow.Cells[3].Value);
            textBox_Direccion.Text = Convert.ToString(dataGridView_Cliente.CurrentRow.Cells[4].Value);
            textBox_Telefono.Text = Convert.ToString(dataGridView_Cliente.CurrentRow.Cells[5].Value);
        }
        #endregion
    }
}
