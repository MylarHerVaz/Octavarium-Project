---
uid: contrib
---
[!include[intro](../../../contributing.md)]

## See also

* [Issue reporting](xref:newissue)