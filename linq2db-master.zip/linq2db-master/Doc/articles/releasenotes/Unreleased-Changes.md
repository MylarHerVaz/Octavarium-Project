This page contains changes and fixes that were not inluded in any release yet and available only through MyGet feed. 

[![MyGet](https://img.shields.io/myget/linq2db/vpre/linq2db.svg)](https://www.myget.org/gallery/linq2db)

# Will be included into next post-2.0 release

none yet

