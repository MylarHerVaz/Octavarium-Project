# Supported databases

* DB2 (LUW, z/OS)
* Firebird
* Informix
* Microsoft Access
* Microsoft Sql Azure
* Microsoft Sql Server
* Microsoft SqlCe
* MySql
* Oracle
* PostgreSQL
* SQLite
* SAP HANA
* Sybase ASE
* [DB2 iSeries](https://github.com/LinqToDB4iSeries/Linq2DB4iSeries)
