# Supported frameworks

-------------
Framework | [linq2db](https://www.nuget.org/packages/linq2db/) | [linq2db.Core](https://www.nuget.org/packages/linq2db.Core/)
---|---|---
.Net 4 | Yes | Yes
.Net 4.5 | Yes | Yes
.Net 4.5.1 |  | Yes
Silverlight 4+ | Yes |
Mono | Yes |
WindowsStore 8 | Yes |
.NETStandard 1.6 |  | Yes