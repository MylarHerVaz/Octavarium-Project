# LINQ Video

* <a target='_blank' href='http://youtu.be/Qc-5UpMYQO0'>LINQ to SqlServer</a>

<a href="http://www.youtube.com/watch?feature=player_embedded&v=Qc-5UpMYQO0" target="_blank"><img src="http://img.youtube.com/vi/Qc-5UpMYQO0/0.jpg" alt="LINQ to SqlServer" width="400"/></a>

* <a target='_blank' href='http://youtu.be/m--oX73EGeQ'>LINQ CRUD Operations</a>

<a href="http://www.youtube.com/watch?feature=player_embedded&v=m--oX73EGeQ" target="_blank"><img src="http://img.youtube.com/vi/m--oX73EGeQ/0.jpg" alt="LINQ CRUD Operations" width="400"/></a>
