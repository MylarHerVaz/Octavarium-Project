using System;

namespace LinqToDB
{
	public static class LinqToDBConstants
	{
		public const string ProductName        = "Linq to DB";
		public const string ProductDescription = "Linq to DB";
		public const string Copyright          = "\xA9 2011-2018 linq2db.com";
	}
}
