﻿using System;

namespace LinqToDB.DataProvider.SqlServer
{
	public enum SqlServerVersion
	{
		v2000,
		v2005,
		v2008,
		v2012,
	}
}
