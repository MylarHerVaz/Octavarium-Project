﻿using System;

namespace LinqToDB.DataProvider.SqlServer
{
	public static class SqlServerConfiguration
	{
		public static bool GenerateScopeIdentity = true;
	}
}
