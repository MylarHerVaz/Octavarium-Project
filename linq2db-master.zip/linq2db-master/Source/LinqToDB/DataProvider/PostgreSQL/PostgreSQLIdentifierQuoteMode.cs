﻿using System;

namespace LinqToDB.DataProvider.PostgreSQL
{
	public enum PostgreSQLIdentifierQuoteMode
	{
		None,
		Quote,
		Needed,
		Auto
	}
}
