﻿using System;

namespace LinqToDB.DataProvider.PostgreSQL
{
	public enum PostgreSQLVersion
	{
		v92,
		v93,
		v95,
	}
}
