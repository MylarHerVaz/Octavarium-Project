﻿using System;

namespace LinqToDB.DataProvider.DB2
{
	public enum DB2IdentifierQuoteMode
	{
		None,
		Quote,
		Auto
	}
}
