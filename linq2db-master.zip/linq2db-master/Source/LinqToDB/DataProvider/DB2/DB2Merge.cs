﻿using System;

namespace LinqToDB.DataProvider.DB2
{
	class DB2Merge : BasicMerge
	{
	}
}
