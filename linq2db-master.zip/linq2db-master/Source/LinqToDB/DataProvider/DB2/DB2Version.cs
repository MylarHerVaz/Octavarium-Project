﻿using System;

namespace LinqToDB.DataProvider.DB2
{
	public enum DB2Version
	{
		LUW,
		zOS,
	}
}
