﻿using System;

namespace LinqToDB.SchemaProvider
{
	public enum AssociationType
	{
		Auto,
		OneToOne,
		OneToMany,
		ManyToOne,
	}
}
