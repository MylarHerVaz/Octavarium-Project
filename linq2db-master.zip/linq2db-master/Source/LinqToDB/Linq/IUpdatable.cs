﻿using System;

namespace LinqToDB.Linq
{
	public interface IUpdatable<T>
	{
	}
}
