﻿using System;

namespace LinqToDB.Linq.Builder
{
	public enum ConvertFlags
	{
		Field,
		Key,
		All,
	}
}
