﻿using System;

#pragma warning disable 649

namespace LinqToDB.Linq.Builder
{
	class ExpressionHoder<TP,TE>
	{
		public TP p;
		public TE ex;
	}
}
