﻿using System;

namespace LinqToDB.Linq
{
	interface ITable
	{
	}
}
