﻿using System;

namespace LinqToDB.Linq
{
	public interface ISelectInsertable<TSource,TTarget>
	{
	}
}
